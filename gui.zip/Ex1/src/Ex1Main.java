import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Ex1Main {

	public static void main(String[] args) {
		// ---- part 1 ----
				JFrame frame = new JFrame();
				frame.setTitle("OOP Week 10: GUI and Event Handling");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setBounds(100, 100, 350, 330);
				frame.setLayout(null);
				//create components
				JLabel label1 = new JLabel("First Name");
				frame.add(label1);
				label1.setBounds(65, 30, 100, 20);
				JTextField inputBox = new JTextField();
				frame.add(inputBox);
				inputBox.setBounds(145, 30, 150, 20);
				
				JLabel label2 = new JLabel("Last Name");
				frame.add(label2);
				label2.setBounds(65, 65, 100, 20);
				JTextField inputBox2 = new JTextField();
				frame.add(inputBox2);
				inputBox2.setBounds(145, 65, 150, 20);
				
				JLabel label3 = new JLabel("Email");
				frame.add(label3);
				label3.setBounds(65, 100, 100, 20);
				JTextField inputBox3 = new JTextField();
				frame.add(inputBox3);
				inputBox3.setBounds(145, 100, 150, 20);

				
				JButton submitButton = new JButton("Submit");
				frame.add(submitButton);
				submitButton.setBounds(120, 260, 80, 20);
				
				JLabel labelg = new JLabel("Gender");
				frame.add(labelg);
				labelg.setBounds(65, 135, 100, 20);
				
				//button
				JRadioButton oneIncrement = new JRadioButton("Male");
				frame.add(oneIncrement);
				oneIncrement.setBounds(135, 135, 60, 20);
				JRadioButton twoIncrement = new JRadioButton("Female");
				frame.add(twoIncrement);
				twoIncrement.setBounds(200, 135, 90, 20);
				ButtonGroup incrementGroup = new ButtonGroup();
				incrementGroup.add(oneIncrement);
				incrementGroup.add(twoIncrement);
				oneIncrement.setSelected(true);
				
				//address
				JLabel labela = new JLabel("Address");
				frame.add(labela);
				labela.setBounds(65, 170, 100, 20);
				JTextArea inputBoxa = new JTextArea();
				frame.add(inputBoxa);
				inputBoxa.setBounds(65, 200, 225, 50);
				
				//event listener
				submitButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
				//getting inputs
					String inputn = inputBox.getText();
					String inputl = inputBox2.getText();
					String inpute = inputBox3.getText();
					String inputa = inputBoxa.getText();
					String mrms = "Mr.";
					
					int countcse = 0;
					
					int count = inpute.indexOf('@');
					int count2 = inpute.indexOf('.');
					
					if(twoIncrement.isSelected()){
						
						mrms = "Ms. ";
					}
					
					if(!inputn.matches("[a-zA-Z]+")){
						JOptionPane.showMessageDialog( frame,
								 "Error! invalid name.",
								 "Error",JOptionPane.ERROR_MESSAGE );
						countcse +=1;
					}
					if(!inputl.matches("[a-zA-Z]+")){
						JOptionPane.showMessageDialog( frame,
								 "Error! invalid lastname.",
								 "Error",JOptionPane.ERROR_MESSAGE );
						countcse +=1;
					}
					
					
					
					if(count == -1 || count2 == -1 || count > count2){
						JOptionPane.showMessageDialog( frame,
								 "Error! invalid email.",
								 "Error",JOptionPane.ERROR_MESSAGE );
						countcse +=1;
					}
					if(countcse == 0){
						JOptionPane.showMessageDialog( frame,
								 mrms+" "+inputn+" "+inputl+" ("+inpute+") "+"\n"+inputa,
								 "Message",JOptionPane.INFORMATION_MESSAGE );
					}
					
					
					
					
							 
			
				 }
				});
				
				//show
				frame.setVisible(true);

	}

}
